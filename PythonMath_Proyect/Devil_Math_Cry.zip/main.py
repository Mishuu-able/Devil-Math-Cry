import customtkinter as ctk
from ui.calculus_view import CalculusView
from ui.limits_view import LimitsView
from ui.algebra_view import AlgebraView
from ui.functions_view import FunctionsView
from ui.exercises_view import ExercisesView
from ui.theme import BG_CONTENT, BG_MODULE, MAIN_BG, MAIN_BUTTON


# ============================================================
# CONFIGURACIÓN
# ============================================================

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")


# ============================================================
# VENTANA PRINCIPAL
# ============================================================

app = ctk.CTk()

app.title("Devil Math Cry")
app.geometry("1000x650")
app.minsize(800, 500)


# ============================================================
# CONTENEDOR PRINCIPAL
# ============================================================

main_container = ctk.CTkFrame(
    app,
    corner_radius=0,
    fg_color=MAIN_BG
)

main_container.pack(
    fill="both",
    expand=True
)


# ============================================================
# MENÚ LATERAL
# ============================================================

sidebar = ctk.CTkFrame(
    main_container,
    width=220,
    corner_radius=0,
    fg_color=MAIN_BG
)

sidebar.pack(
    side="left",
    fill="y"
)

sidebar.pack_propagate(False)


# ============================================================
# TÍTULO DEL MENÚ
# ============================================================

logo = ctk.CTkLabel(
    sidebar,
    text="Devil Math Cry",
    font=ctk.CTkFont(
        family="Old English Text MT",
        size=26,
        weight="bold"
    )
)

logo.pack(
    pady=(35, 5)
)


subtitle = ctk.CTkLabel(
    sidebar,
    text="Matemáticas Universitarias",
    font=ctk.CTkFont(size=16,
                     family= "Perpetua")
)

subtitle.pack(
    pady=(0, 35)
)


# ============================================================
# FUNCIONES DEL MENÚ
# ============================================================


def limpiar_modulo():
    for widget in module_container.winfo_children():
        widget.destroy()

def ocultar_bienvenida():
    header.pack_forget()

    content.configure(fg_color=BG_MODULE)
    module_container.configure(fg_color=BG_MODULE)


def mostrar_calculo():
    ocultar_bienvenida()
    limpiar_modulo()
    CalculusView(module_container)


def mostrar_limites():
    ocultar_bienvenida()
    limpiar_modulo()
    LimitsView(module_container)


def mostrar_algebra():
    ocultar_bienvenida()
    limpiar_modulo()

    AlgebraView(module_container)


def mostrar_funciones():
    ocultar_bienvenida()
    limpiar_modulo()

    FunctionsView(module_container)

def mostrar_ejercicios():
    ocultar_bienvenida()
    limpiar_modulo()

    ExercisesView(module_container)



# ============================================================
# BOTONES
# ============================================================

boton_algebra = ctk.CTkButton(
    sidebar,
    text="Álgebra",
    height=45,
    fg_color=MAIN_BUTTON,
    hover_color=MAIN_BUTTON,
    command=mostrar_algebra
)

boton_algebra.pack(
    padx=20,
    pady=8,
    fill="x"
)


boton_calculo = ctk.CTkButton(
    sidebar,
    text="Cálculo",
    height=45,
    fg_color=MAIN_BUTTON,
    hover_color=MAIN_BUTTON,
    command=mostrar_calculo
)

boton_calculo.pack(
    padx=20,
    pady=8,
    fill="x"
)


boton_funciones = ctk.CTkButton(
    sidebar,
    text="Funciones",
    height=45,
    fg_color=MAIN_BUTTON,
    hover_color=MAIN_BUTTON,
    command=mostrar_funciones
)

boton_funciones.pack(
    padx=20,
    pady=8,
    fill="x"
)


boton_ejercicios = ctk.CTkButton(
    sidebar,
    text="Ejercicios",
    height=45,
    fg_color=MAIN_BUTTON,
    hover_color=MAIN_BUTTON,
    command=mostrar_ejercicios
)

boton_ejercicios.pack(
    padx=20,
    pady=8,
    fill="x"
)

boton_limites = ctk.CTkButton(
    sidebar,
    text="Límites",
    fg_color=MAIN_BUTTON,
    hover_color=MAIN_BUTTON,
    command=mostrar_limites
)

boton_limites.pack(
    padx=20,
    pady=5,
    fill="x"
)


#
# ============================================================
# ÁREA DE CONTENIDO
# ============================================================

content = ctk.CTkFrame(
    main_container,
    corner_radius=0,
    fg_color=BG_CONTENT
)

content.pack(
    side="right",
    fill="both",
    expand=True,
    padx=0,
    pady=0
)

# ============================================================
# ENCABEZADO (NO SE DESTRUYE AL CAMBIAR DE MÓDULO)
# ============================================================

header = ctk.CTkFrame(
    content,
    fg_color="transparent"
)

header.pack(fill="x")

titulo_contenido = ctk.CTkLabel(
    header,
    text="Bienvenido a Devil Math Cry",
    font=ctk.CTkFont(size=32, weight="bold", family= "Book Antiqua")
)

titulo_contenido.pack(pady=(30, 20))

descripcion = ctk.CTkLabel(
    header,
    text=(
        "Una herramienta para estudiar "
        "matemáticas universitarias.\n\n"
        "Selecciona un módulo del menú lateral."
    ),
    font=ctk.CTkFont(size=18,
                     family= "Baskerville Old Face"),
    justify="center"
)

descripcion.pack(pady=20)

# ============================================================
# CONTENEDOR EXCLUSIVO PARA LOS MÓDULOS
# ============================================================

module_container = ctk.CTkFrame(
    content,
    fg_color="transparent",
    corner_radius=0
)

module_container.pack(
    fill="both",
    expand=True,
    padx=0,
    pady=0
)

# ============================================================
# EJECUTAR
# ============================================================

app.mainloop()
